# Atlas Daughter Production Standard V2 — Candidate Release

This package contains three execution-reference daughter builds:

- **Road LTL V1.4** — 22-task operational-depth candidate built from frozen Road LTL lineage + Operational Knowledge V0.2 + enriched client-binding manifest.
- **Ocean FCL V0.6** — 30-task execution-reference candidate over frozen FCL V0.5.
- **Ocean LCL V0.6** — 30-task execution-reference candidate over frozen LCL V0.5, preserving separate house/master semantics.

## What changed

The daughter model now explicitly carries **what must exist + when + why + constraints + decision/control behavior + expected outcome**, plus source-aware client-binding contracts.

The actual client values remain intentionally empty where they are legitimately variable.

## Open locally

Open `index.html` directly. It is a standalone renderer with all three candidate modules embedded.

## Backend

`backend/supabase/001_knowledge_execution_warehouse.sql` is the persistence model for editable/versioned modules, tasks, claims, operational requirements, decision gates, transitions, bindings, decomposition nodes and WorkDefinitions.

## Status

**Candidate — not yet ACTIVE.** The next gate is full semantic regression against frozen Road LTL V1.3 / Ocean V0.5 followed by Work Decomposition + WorkDefinition compilation.
