# Inside-Out + Outside-In Audit — LTL V1.4 / Ocean FCL & LCL V0.6

## Release method

This build applies the frozen Daughter Production Standard V2:

**Universe → Daughter Domain Model → Operational Knowledge → Recursive Work Decomposition → Canonical WorkDefinition → Client Binding → Runtime Projection → Execution.**

The daughter release stops at the **execution-reference boundary**: it defines what must exist, when, why, validation/constraints, decisions, controls, actions, branches, evidence, outcomes and all known binding slots. It does **not** embed Malkom queues, client SAP/TMS field names, negotiated SLA values or client authority limits.

## Inside-out pass

For every A5 task the build asks whether the current daughter tells a future executor:

1. what triggers the work and what state precedes it;
2. what information is required and where that value class comes from;
3. which decision gates consume those inputs;
4. what validates or blocks progression;
5. what state-changing action is permitted;
6. how pass/fail/hold/retry/escalation branches behave;
7. which clocks/timers must be source- or binding-resolved;
8. which role/system owns/authorizes work;
9. what evidence proves completion;
10. what remains a legitimate client binding rather than missing domain knowledge.

## Outside-in pass

Ocean V0.6 uses DCSA Booking, Commercial Schedules, eBL, VGM, Track & Trace and Port Call; IMO SOLAS VGM, IMDG and FAL/MSW; the IMO/ILO/UNECE CTU Code; FIATA house-document context; FMC OTI/NVOCC role context; and UN/CEFACT transport data semantics.

Road LTL V1.4 combines the frozen Atlas task model with the previously researched 22-task Operational Knowledge V0.2 and the 128-slot binding manifest.

## Key finding

The remaining client dependency is no longer “explain the operation.” The client side is largely reduced to:

- actual system/application names and field/API mappings;
- negotiated/commercial values;
- carrier/facility cut-offs and service parameters where no universal value exists;
- organization-specific decision/approval/escalation ownership;
- client master/network records;
- local code crosswalks and policy selections within the source-governed envelope.

## Source boundary

`SOURCE_EXPLICIT` is reserved for requirements stated by the governing source (for example SOLAS VGM as a load condition). Most end-to-end sequencing and task contracts are `SOURCE_DERIVED` or `ATLAS_DERIVED`, with cited source scope retained. Client configuration is never represented as universal truth.

## Promotion boundary

These files are **execution-ready reference candidates**, not proof of runtime execution. Promotion to an execution-certified WorkDefinition requires recursive decomposition + canonical WorkDefinition compilation + client binding + independent executor test.
