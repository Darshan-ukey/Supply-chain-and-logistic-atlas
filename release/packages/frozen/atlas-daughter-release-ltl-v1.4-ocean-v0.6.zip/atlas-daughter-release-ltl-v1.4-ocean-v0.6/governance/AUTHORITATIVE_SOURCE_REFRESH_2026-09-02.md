# Authoritative Operational Source Refresh — 2 September 2026

The V2 daughter build deliberately uses operational sources below the APQC/SCOR framework layer.

## Ocean source positions revalidated

- **DCSA Commercial Schedules 1.0.3 (12 Jun 2026):** point-to-point routing and vessel/port schedule exchange; schedule is planning information, not booking commitment.
- **DCSA Booking 2.0.4 (13 Apr 2026):** structured booking lifecycle and data model, including routing/location/party/equipment/cargo information.
- **DCSA Bill of Lading 3.0.3 (13 Apr 2026):** Shipping Instructions + Transport Document lifecycle; includes customs-specific cargo-description/marks fields, extended HS/national commodity-code support and amendment/cancellation behavior.
- **DCSA VGM 1.0.1 (13 Mar 2026):** VGM submission/update/retrieval/forwarding and interoperable interface/data behavior.
- **DCSA Track & Trace 2.2:** common container-shipping event semantics across pre-shipment, pre-ocean, ocean, post-ocean and post-shipment phases.
- **DCSA Port Call 2.0:** port-call operational information exchange.
- **IMO SOLAS VGM:** shipper provides verified gross mass; availability sufficiently in advance for stowage planning is a prerequisite and VGM is a condition for vessel loading of packed containers subject to SOLAS.
- **IMO IMDG 2024 / Amendment 42-24:** mandatory from 1 Jan 2026; dangerous-goods requirements remain a conditional overlay rather than universal cargo logic.
- **IMO FAL / Maritime Single Window:** mandatory MSW since 1 Jan 2024 for electronic arrival/stay/departure information exchange with public authorities.
- **IMO/ILO/UNECE CTU Code:** authoritative non-mandatory global packing/securing/handling practice; it should constrain packing knowledge but is not treated as a universal legal mandate.
- **FMC OTI context:** distinguishes Ocean Freight Forwarder and NVOCC roles in U.S. trades; NVOCC issues its own house bill/equivalent and is shipper in relation to the vessel-operating common carrier.

## Road LTL source positions retained

The build retains the prior Road LTL operational-source research: NMFTA/DSDC eBOL and Pickup Request/Visibility, GS1/EPCIS event/identity semantics, U.S. Part 370 claims, and conditional hazmat regulatory overlays. Exact client operating parameters remain binding values rather than invented industry truths.

## Source boundary rule

Sources establish canonical objects, fields, lifecycle semantics, regulatory conditions, decision constraints and evidence requirements where they actually support them. End-to-end Atlas task composition is explicitly labelled `SOURCE_DERIVED` or `ATLAS_DERIVED` unless the source itself states the exact requirement.
